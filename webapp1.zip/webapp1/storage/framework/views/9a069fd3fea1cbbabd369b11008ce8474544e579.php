<form method="post" action="<?php echo e(route('Share.store')); ?>">
<?php echo csrf_field(); ?>
<table>
<tr>
<th>Title</th>
<td>
<input type="text" name="title">
</td>
</tr>
<tr>
<th>Body</th>
<td>
<input type="text" name="body">
</td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Submit"></td> 
</tr>
</table>
</form>
