<table border="1">
<?php echo e($share); ?>

<tr>
<td>id</td>
<td>title</td>
<td>body</td>
<td>edit</td>
<td>delete</td>
</tr>
<tr>
<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
</tr>
<tr>
<td><?php echo e($value->id); ?></td>
<td><?php echo e($value->title); ?></td>
<td><?php echo e($value->body); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>