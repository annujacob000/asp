@extends('layouts.annu')
@section('content')
<h1>Annu</h1>
<p>Hai How r u?</p>
@endsection