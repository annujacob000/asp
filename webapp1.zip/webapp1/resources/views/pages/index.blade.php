
@extends('layouts.annu')
@section('content')
<h1>Home</h1>
<h2>{{$titles}}</h2> 
<p>Amal Jyothi College </p>
@endsection