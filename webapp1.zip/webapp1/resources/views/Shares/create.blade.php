<form method="post" action="{{route('Share.store')}}">
@csrf
<table>
<tr>
<th>Title</th>
<td>
<input type="text" name="title">
</td>
</tr>
<tr>
<th>Body</th>
<td>
<input type="text" name="body">
</td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Submit"></td> 
</tr>
</table>
</form>
