<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index()
    {
        $name="Annu";
        //return "hai annu";
       // return view('pages.index',compact('name'));
       return view('pages.index')->with('titles',$name);
    }
    public function about()
    {
        //return "hai annu";
        return view('pages.about');
    }
    public function service()
    {
        //return "hai annu";
        return view('pages.service');
    }
    //
}
