﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcApplication2.Models
{
    public class UserDemo
    {
        public int UserDemoId {get;set;}

        [Required]
        [Display(Name="Name")]
        public String name { get; set; }

        [Required]
        [Display(Name = "User name")]
        public String uname { get; set; }

        [Required]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public String pwd { get; set; }

    }
}