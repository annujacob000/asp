﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebApplication4.Controllers
{
    public class User
    {
        public int Id {get; set;}
        [Required]
        [Display(Name = "Name")]
        //[RegularExpression("45667mgjhg")]
        public string uname { get; set; }

        [Required]
        [Display(Name = "user name")]
        //[DataType(DataType.EmailAddress, ErrorMessage = "Enter valid email")]
        public string username { get; set; }

        [Required]
        //[DataType(DataType.MultilineText)]
        [Display(Name = "Password")]
        [MaxLength(8, ErrorMessage = "Up to 8 characters")]
        public string password { get; set; }
    }
}