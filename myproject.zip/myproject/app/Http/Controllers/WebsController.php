<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WebsController extends Controller
{
public function register(){
		//return "hai mariya";
		return view('web.register');
	}

}